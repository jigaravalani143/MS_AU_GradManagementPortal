export interface Institute{
    id:number;
    name:string;
}