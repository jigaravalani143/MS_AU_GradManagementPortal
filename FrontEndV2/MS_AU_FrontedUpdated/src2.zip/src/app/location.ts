export interface Location{
    id:number;
    name:string;
}